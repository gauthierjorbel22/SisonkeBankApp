package com.example.sisonkebank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    /** Declaration of User Interface variables and components **/
    private Button loginBtn;
    private EditText mymailTxt;
    private EditText mypassTxt;
    private TextView registerTxtVw;
    private DBHelper myDatabase = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //UI init
        this.loginBtn = findViewById(R.id.buttonLogin);
        this.mymailTxt = findViewById(R.id.editTextEmailReg);
        this.mypassTxt = findViewById(R.id.editTextPasswordReg);
        this.registerTxtVw = findViewById(R.id.textViewRegister);

        /** Listeners for buttons (login, register)**/

        this.loginBtn.setOnClickListener(event -> {
            // get text of components
            String mymail = this.mymailTxt.getText().toString();
            String mypass = this.mypassTxt.getText().toString();

            // check some conditions
            if (!this.validate(mymail, mypass)) return;

            // authentication
            this.authenticateUser(mymail, mypass);
        });

        // add registerTxtVw to listener
        this.registerTxtVw.setOnClickListener(event -> {
            // go to main activity
            startActivity(new Intent(this, RegisterActivity.class));
        });

    }

    // TODO: implement authentication
    private void authenticateUser(String mymail, String mypass) {
        // instantiation of database
        myDatabase = new DBHelper(this);

        // check if mymail is not registered
        boolean isRegistered = myDatabase.checkIfRegistered(mymail);
        if (!isRegistered) {
            Toast.makeText(this, String.format("No account matching mymail %s", mymail), Toast.LENGTH_SHORT).show();
            return;
        }

        // if authenticated
        // go to main activity
        int userId = myDatabase.authenticateUser(mymail, mypass);
        if (userId != -1) {
            Toast.makeText(this, String.format("%s You are successfully logged in!", mymail), Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class).putExtra("userId", userId));
            finish();
        } else {
            Toast.makeText(this, "Password is incorrect!", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validate(String mymail, String mypass) {
        // check if empty
        if (TextUtils.isEmpty(mymail)) {
            Toast.makeText(this, "Please enter a valid  email address", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (TextUtils.isEmpty(mypass)) {
            Toast.makeText(this, "Please enter a valid password", Toast.LENGTH_SHORT).show();
            return false;
        }


        // check if mymail is valid
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(mymail).matches()) {
            Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
            return false;
        }

        // check if mypass is 5 characters
        if (mypass.length() < 5) {
            Toast.makeText(this, "The password must be more than 5 characters", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}