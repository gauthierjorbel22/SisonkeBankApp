package com.example.sisonkebank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    // declare ui components
    private Button registerBtn;
    private EditText fname;
    private EditText last_name;
    private TextView loginTextView;
    private RadioGroup genderRadioGroup;
    private String gender = "";
    private DBHelper myDatabase = null;
    private EditText mymailTxt;
    private EditText mypassTxt;
    private EditText phoneEditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        // Initialization of User Interface
        registerBtn = findViewById(R.id.buttonRegister);
        fname = findViewById(R.id.editTextFirstName);
        last_name = findViewById(R.id.editTextLastName);
        mymailTxt = findViewById(R.id.editTextEmailReg);
        mypassTxt = findViewById(R.id.editTextPasswordReg);
        phoneEditText = findViewById(R.id.editTextPhone);
        genderRadioGroup = findViewById(R.id.radioGroupGender);
        loginTextView = findViewById(R.id.textViewLogin);



        // Click listeners
        registerBtn.setOnClickListener(event -> {
            // get text components to edit
            String fname = this.fname.getText().toString();
            String last_name = this.last_name.getText().toString();
            String mymail = this.mymailTxt.getText().toString();
            String mypass = this.mypassTxt.getText().toString();
            String mobile = this.phoneEditText.getText().toString();
            double savingsAccountBalance = 5200;
            double currentAccountBalance = 3900;

            // call validation
           if(!validate(fname, last_name, mymail, mypass, mobile, gender)) return;

           BankUser user = new BankUser(fname, last_name, mymail, mypass, mobile, gender, currentAccountBalance, savingsAccountBalance);

           // registering a user
            registerUser(user);
        });

        loginTextView.setOnClickListener(event -> {
            // go to main activity
            startActivity(new Intent(this, LoginActivity.class));
        });

        genderRadioGroup.setOnCheckedChangeListener((radioGroup, id) -> {
            RadioButton selectedBtn = findViewById(id);
            gender = selectedBtn.getText().toString();
        });
    }
    // registration
    private void registerUser(BankUser bankUser) {
        // get database instance
        myDatabase = new DBHelper(this);

        // check if the email address is already registered
        boolean isRegistered = myDatabase.checkIfRegistered(bankUser.getEmail());

        if (isRegistered) {
            Toast.makeText(this, String.format("Email: %s is already registered", bankUser.getEmail()), Toast.LENGTH_SHORT).show();
        } else {
            // TODO: hash password and save

            // save the user to database
            if (myDatabase.addUser(bankUser)) {
                // display toast
                Toast.makeText(this, String.format("New account for mymail: %s registered successfully", bankUser.getEmail()), Toast.LENGTH_SHORT).show();

                // go to main activity
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            } else {
                // show toast
                Toast.makeText(this, String.format("Something went wrong, account not created for mymail: %s", bankUser.getEmail()), Toast.LENGTH_SHORT).show();


            }

        }

    }

    private boolean validate(String fname, String last_name, String mymail, String mypass, String mobile, String gender) {
        if (TextUtils.isEmpty(fname)) {
            Toast.makeText(this, "Please enter first name", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (TextUtils.isEmpty(last_name)) {
            Toast.makeText(this, "Please enter last name", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (TextUtils.isEmpty(mymail)) {
            Toast.makeText(this, "Please enter the email address", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(mymail).matches()) {
            Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (TextUtils.isEmpty(mypass)) {
            Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show();
            return false;
        } else if (mypass.length() < 5) {
                Toast.makeText(this, "Password must be more than 5 characters", Toast.LENGTH_SHORT).show();
                return false;
        }

        if (TextUtils.isEmpty(mobile)) {
            Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (TextUtils.isEmpty(gender)) {
            Toast.makeText(this, "Please select gender", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}
