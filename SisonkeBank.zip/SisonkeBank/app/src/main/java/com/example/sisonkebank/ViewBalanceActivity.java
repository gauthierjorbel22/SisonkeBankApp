package com.example.sisonkebank;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.Objects;

public class ViewBalanceActivity extends AppCompatActivity {
    private TextView holderFirstNameTextView;
    private TextView holderLastNameTextView;
    private TextView currentAccBalanceTxt;
    private TextView savingsAccountBalanceTextView;
    private BankUser bankUser;
    private DBHelper myDatabase = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_account_balance);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        // get extras
        Bundle extras = getIntent().getExtras();

        // instance of database
        myDatabase = new DBHelper(this);

        // Initialisation of User Interface elements
        holderFirstNameTextView = findViewById(R.id.textViewHolderFirstName);
        holderLastNameTextView = findViewById(R.id.textViewHolderSurname);
        currentAccBalanceTxt = findViewById(R.id.textViewCurrentAccountBalance);
        savingsAccountBalanceTextView = findViewById(R.id.textViewSavingsAccountBalance2);

        // get user details
        bankUser = myDatabase.getUserDetails(extras.getInt("userId"));

        // append values
        holderFirstNameTextView.append(" " + bankUser.getFirstName());
        holderLastNameTextView.append(" " + bankUser.getLastName());
        currentAccBalanceTxt.append(" R" + bankUser.getCurrentAccountBalance());
        savingsAccountBalanceTextView.append(" R" + bankUser.getSavingsAccountBalance());
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}