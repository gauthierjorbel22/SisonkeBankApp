package com.example.sisonkebank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int userId;
    private BankUser bankUser;
    private DBHelper myDatabase = null;
    private TextView welcomeTxt;
    private Button viewBalanceBtn;
    private Button transferBetweenAccountsButton;
    private Button logoutBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // get database instance
        myDatabase = new DBHelper(this);

        // get extras
        Bundle extras = getIntent().getExtras();

        // Database initialisation
        bankUser = myDatabase.getUserDetails(extras.getInt("userId"));

        welcomeTxt = findViewById(R.id.textViewWelcome);
        viewBalanceBtn = findViewById(R.id.buttonViewBalance);
        transferBetweenAccountsButton = findViewById(R.id.buttonAccountTransfer);
        logoutBtn = findViewById(R.id.buttonLogout);

        // set welcome text
        String fname = bankUser.getFirstName();
        welcomeTxt.append(" " + fname);

        viewBalanceBtn.setOnClickListener(event -> {
            // go to view balance activity
            startActivity(new Intent(this, ViewBalanceActivity.class).putExtra("userId", extras.getInt("userId")));
        });

        transferBetweenAccountsButton.setOnClickListener(event -> {
            // go to transfer activity
            startActivity(new Intent(this, TransferActivity.class).putExtra("userId", extras.getInt("userId")));
        });

        logoutBtn.setOnClickListener(event -> {
            Toast.makeText(this, "User has successfully logged out", Toast.LENGTH_SHORT).show();

            // go to login activity
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

//        Toast.makeText(this, "here is the UID: " + userId, Toast.LENGTH_LONG).show();
    }
}
