package com.example.sisonkebank;

public class BankUser {
    private String mymail;
    private String mypass;
    private int id;
    private String fname;
    private String mobile;
    private String gender;
    private String last_name;
    private double currentAccountBalance;
    private double savingsAccountBalance;

    public BankUser() {
    }

    public BankUser(int id, String fname, String last_name, String mymail, String mypass, String mobile, String gender, double currentAccountBalance, double savingsAccountBalance) {
        this.id = id;
        this.fname = fname;
        this.last_name = last_name;
        this.mymail = mymail;
        this.mypass = mypass;
        this.mobile = mobile;
        this.gender = gender;
        this.currentAccountBalance = currentAccountBalance;
        this.savingsAccountBalance = savingsAccountBalance;
    }

    public BankUser(String fname, String last_name, String mymail, String mypass, String mobile, String gender, double currentAccountBalance, double savingsAccountBalance) {
        this.fname = fname;
        this.last_name = last_name;
        this.mymail = mymail;
        this.mypass = mypass;
        this.mobile = mobile;
        this.gender = gender;
        this.currentAccountBalance = currentAccountBalance;
        this.savingsAccountBalance = savingsAccountBalance;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setFirstName(String fname) {
        this.fname = fname;
    }

    public void setLastName(String last_name) {
        this.last_name = last_name;
    }

    public void setEmail(String mymail) {
        this.mymail = mymail;
    }

    public void setPassword(String mypass) {
        this.mypass = mypass;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getFirstName() {
        return fname;
    }

    public String getLastName() {
        return last_name;
    }

    public String getEmail() {
        return mymail;
    }

    public String getPassword() {
        return mypass;
    }

    public String getMobile() {
        return mobile;
    }

    public String getGender() {
        return gender;
    }

    public double getCurrentAccountBalance() {
        return currentAccountBalance;
    }

    public double getSavingsAccountBalance() {
        return savingsAccountBalance;
    }

    public void setCurrentAccountBalance(double currentAccountBalance) {
        this.currentAccountBalance = currentAccountBalance;
    }

    public void setSavingsAccountBalance(double savingsAccountBalance) {
        this.savingsAccountBalance = savingsAccountBalance;
    }
}
